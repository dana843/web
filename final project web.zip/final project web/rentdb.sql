-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2021 at 08:29 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rentdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact_messages`
--

CREATE TABLE `tbl_contact_messages` (
  `message_id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_contact_messages`
--

INSERT INTO `tbl_contact_messages` (`message_id`, `full_name`, `email`, `message`) VALUES
(1, 'dana hhh', 'danah1@gmail.com', 'fdsafdsafdsaf'),
(2, 'reema', 'reema@gmail.com', 'jjj'),
(3, 'QQ OO', 'QQ@GMAIL.COM', 'KKK'),
(4, 'QQ OO', 'QQ@GMAIL.COM', 'gg'),
(5, 'hosny', 'hosnyish812@gmail.com', 'hello im hosny i want to rent my bike to go '),
(6, 'hosnyyyyy', 'p1p2001@hotmail.com', 'hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii'),
(7, 'QQ OO', 'QQ@GMAIL.COM', 'hi  hihi');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `product_id` int(11) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `product_sn` varchar(255) NOT NULL,
  `product_type` varchar(255) NOT NULL,
  `product_rate` double NOT NULL,
  `product_price` double NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`product_id`, `product_title`, `product_image`, `product_sn`, `product_type`, `product_rate`, `product_price`, `created_at`, `updated_at`) VALUES
(1, 'electrical bike', './images/pro1.jfif', '116a', 'electrical bikes', 4.5, 190, '2021-05-06 19:53:42', '2021-05-06 19:53:42'),
(2, 'electrical bike', './images/pro9.jpg', '116b', 'electrical bikes', 3.5, 150, '2021-05-06 19:54:19', '2021-05-06 19:54:19'),
(3, 'electrical bike', './images/pro7.jpg', '116c', 'electrical bikes', 3, 100, '2021-05-07 02:59:57', '2021-05-07 02:59:57'),
(4, 'electrical bike', './images/epro1.jpeg', '116d', 'electrical bikes', 2.5, 50, '2021-05-07 02:59:57', '2021-05-07 02:59:57'),
(5, 'Street bike', './images/spro1.jpg', '115a', 'Street bikes', 4.5, 90, '2021-05-07 03:09:12', '2021-05-07 03:09:12'),
(6, 'Street bike', './images/spro2.jpg', '115b', 'Street bikes', 2.5, 50, '2021-05-07 03:09:12', '2021-05-07 03:09:12'),
(7, 'Street bike', './images/pro2.jpg', '115c', 'Street bikes', 3.5, 90, '2021-05-07 03:12:27', '2021-05-07 03:12:27'),
(8, 'Street bike', './images/spro3.jpg.', '115d', 'Street bikes', 4.5, 50, '2021-05-07 03:12:27', '2021-05-07 03:12:27'),
(9, 'Mountain bike', './images/mpro1.jpg', '114a', 'Mountain Bikes', 4.5, 90, '2021-05-07 03:13:29', '2021-05-07 03:13:29'),
(10, 'Mountain bike', './images/mpro2.jpg', '114b', 'Mountain Bikes', 2.5, 50, '2021-05-07 03:13:29', '2021-05-07 03:13:29'),
(11, 'Mountain bike', './images/mpro3.jpg', '114c', 'Mountain Bikes', 4.5, 90, '2021-05-07 03:18:49', '2021-05-07 03:18:49'),
(12, 'Mountain bike', './images/mpro4.jfif', '114d', 'Mountain Bikes', 3.5, 50, '2021-05-07 03:18:49', '2021-05-07 03:18:49'),
(13, 'smart bike', './images/pro1.jfif', '112a', 'smart_bike', 5, 190, '2021-05-07 03:20:56', '2021-05-07 03:20:56');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rent`
--

CREATE TABLE `tbl_rent` (
  `rent_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rent_details` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_rent`
--

INSERT INTO `tbl_rent` (`rent_id`, `product_id`, `user_id`, `rent_details`) VALUES
(1, 1, 1, 1),
(2, 2, 6, 2),
(3, 3, 6, 3),
(4, 11, 6, 4),
(5, 10, 6, 5),
(6, 2, 6, 6),
(7, 1, 8, 7);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rent_details`
--

CREATE TABLE `tbl_rent_details` (
  `ID` int(11) NOT NULL,
  `de_phone` varchar(255) NOT NULL,
  `de_ccn` varchar(255) NOT NULL,
  `de_type_bike` varchar(255) NOT NULL,
  `de_sn_bike` varchar(150) NOT NULL,
  `start_date` varchar(255) NOT NULL,
  `end_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_rent_details`
--

INSERT INTO `tbl_rent_details` (`ID`, `de_phone`, `de_ccn`, `de_type_bike`, `de_sn_bike`, `start_date`, `end_date`) VALUES
(1, '0587270216', '2849848-65165', 'electrical bikes', '116a', '2021-05-06', '2021-05-07'),
(2, '0587270216', '2849848-65165', 'electrical bikes', '116b', '2021-05-12', '2021-05-27'),
(3, '0587270216', '516516516561', 'electrical bikes', '116c', '2021-05-07', '2021-05-06'),
(4, '22222222222222', '222222222222', 'Mountain Bikes', '114c', '2000-12-10', '2007-05-03'),
(5, '0598060757', '1211121252121', 'Mountain Bikes', '114b', '2021-12-05', '2021-12-06'),
(6, '0598060757', '14141414', 'electrical bikes', '116b', '2021-08-05', '2021-09-05'),
(7, '0598060757', '1111-2222-3333-4444', 'electrical bikes', '116a', '2021-11-30', '2021-12-01');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `first_name`, `last_name`, `user_email`, `password`) VALUES
(5, 'dana', 'hamad', 'danah1@gmail.com', '4a7d1ed414474e4033ac29ccb8653d9b'),
(6, 'QQ', 'OO', 'QQ@GMAIL.COM', '4a7d1ed414474e4033ac29ccb8653d9b'),
(9, 'mokhles', 'ishtaya', 'mokhlesish@gmail.com', 'dbc4d84bfcfe2284ba11beffb853a8c4'),
(10, 'mohammed', 'ishtaya', 'mohammedish812@gmail.com', '6074c6aa3488f3c2dddff2a7ca821aab'),
(11, 'qussay', 'ishtaya', 'dr.qussayishtaya@gmail.com', 'e9510081ac30ffa83f10b68cde1cac07'),
(13, 'hosny', 'khalil ', 'hosnyish812@gmail.com', '97788494d0cb9c4ad37af9a76290b361');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_contact_messages`
--
ALTER TABLE `tbl_contact_messages`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `tbl_rent`
--
ALTER TABLE `tbl_rent`
  ADD PRIMARY KEY (`rent_id`);

--
-- Indexes for table `tbl_rent_details`
--
ALTER TABLE `tbl_rent_details`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_contact_messages`
--
ALTER TABLE `tbl_contact_messages`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_rent`
--
ALTER TABLE `tbl_rent`
  MODIFY `rent_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_rent_details`
--
ALTER TABLE `tbl_rent_details`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
